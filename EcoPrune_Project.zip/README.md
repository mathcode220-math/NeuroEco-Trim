# EcoPrune 🌿
## Neuroevolutionary Architecture Discovery via Ecological Pruning

**اكتشاف البنية العصبية بالتطور البيئي**

---

## الملخص | Abstract

**EcoPrune** هو إطار عمل (Framework) لـ **اكتشاف حجم الطبقات المخفية تلقائياً** في الشبكات العصبية، مُستوحى من النظم البيولوجية:

- **الموت الخلوي المبرمج (Apoptosis)**: تقليم هيكلي حقيقي للروابط المريضة
- **التحلل العضوي (Composting)**: إعادة تدوير المعرفة المُكتسبة
- **تكوين الأعصاب (Neurogenesis)**: نمو جديد من مواد الكمبوست المُعاد تدويرها

**الفرضية الأساسية**: بدء التدريب بشبكة مُفرطة (Over-parameterized) ثم تقليمها تدريجياً مع ضبط دقيق يكتشف أحجاماً مخفية أفضل من التصميم اليدوي.

---

## النتائج | Results

### Spiral Classification Benchmark

| النموذج | المعاملات | الدقة | الملاحظة |
|---------|-----------|-------|----------|
| Large Baseline | 42,115 | 71.5% | تصميم يدوي |
| **EcoPrune (Ours)** | **23,372** | **72.8%** | **اكتشاف تلقائي** |
| Same-Size Baseline | 23,372 | 70.0% | تصميم يدوي بنفس الحجم |

**الخلاصة**: النموذج البيئي يتفوق على التصميم اليدوي بنفس الحجم بـ **+2.8%**، وعلى النموذج الكبير بـ **+1.3%** مع تقليص **44.5%** من المعاملات.

---

## المبدأ العلمي | Scientific Principle

### 1. تتبع الصحة (Health Tracking)
بدلاً من قياس حجم الوزن فقط، نستخدم **الحساسية**:

```
health_ij = EMA(|weight_ij * gradient_ij|)
```

هذا يقيس **مدى تأثير الوزن على الخسارة**، لا حجمه المطلق.

### 2. التقليم الهيكلي (Structural Pruning)
نحذف **صفوف كاملة** (output neurons) ذات صحة منخفضة، ونعيد تشكيل المصفوفات فعلياً — لا نكتفي بتصفيرها.

### 3. إعادة التدوير (Knowledge Recycling)
الأوزان المحذوفة لا تُهدر. تُحفظ في **كومة الكمبوست** (Compost Heap) ويُعاد استخدام توزيعها الإحصائي لتهيئة الروابط الجديدة.

---

## الاستخدام | Usage

```python
from ecoprune import EcoNet, train_ecological, make_spiral
import torch

# 1. إنشاء الشبكة البيئية
model = EcoNet([2, 256, 128, 64, 3])

# 2. تحضير البيانات
X_train, y_train = make_spiral(400, 3, 0.25)
X_test, y_test = make_spiral(200, 3, 0.25)

# 3. التدريب البيئي
history = train_ecological(
    model, X_train, y_train, X_test, y_test,
    total_epochs=200,
    prune_epochs=[60, 100, 140],
    prune_quantile=0.10,
    finetune_epochs=30,
    lr=0.02
)

# 4. النتيجة
print(f"Final structure: {model.current_sizes}")
print(f"Parameters: {model.count_params():,}")
```

---

## البروتوكول التدريبي | Training Protocol

```
Epoch 0-60   : تدريب أولي (اكتساب المعرفة)
Epoch 60     : تقليم خفيف (10%) + ضبط دقيق 30 epoch
Epoch 60-100 : استقرار
Epoch 100    : تقليم ثانٍ + ضبط دقيق
Epoch 100-140: استقرار
Epoch 140    : تقليم ثالث + ضبط دقيق
Epoch 140-200: استقرار نهائي
```

---

## الملفات | Files

| الملف | الوصف |
|-------|-------|
| `ecoprune.py` | الكود المصدري الكامل |
| `ecoprune_v2_final.png` | الرسم البياني التوضيحي للنتائج |
| `final_ecological_summary.png` | الملخص البصري |
| `ecological_network_evolution.png` | تطور الشبكة عبر الزمن |
| `README.md` | هذا الملف |

---

## الحالة البحثية | Research Status

> ⚠️ **هذا نموذج بحثي (Research Prototype)**، ليس أداة إنتاج جاهزة.

### ما تم إثباته
✅ التقليم الهيكلي يعمل (تقلص فعلي للمصفوفات)  
✅ تتبع الصحة بالحساسية يتفوق على العتبة الثابتة  
✅ الاكتشاف التلقائي يتفوق على التصميم اليدوي بنفس الحجم  

### ما يحتاج تطويراً
🔧 اختبار على MNIST / CIFAR-10  
🔧 مقارنة مع Lottery Ticket Hypothesis  
🔧 تحسين جدول الضبط الدقيق  
🔧 دعم الشبكات التلافيفية (CNNs)  

---

## المراجع | References

1. Frankle, J., & Carlin, N. (2018). *The Lottery Ticket Hypothesis*. ICML.
2. Han, S., Mao, H., & Dally, W. (2015). *Deep Compression*. ICLR.
3. Molchanov, P., et al. (2019). *Importance Estimation for Neural Network Pruning*. CVPR.

---

## الترخيص | License

MIT License - مفتوح المصدر للجميع.

---

**صنع بـ ❤️ وعلم 🔬**
